# 📚 Chat with Your Notes - Advanced AI Document Q&A System

A powerful, feature-rich web application that allows users to upload, manage, and query their documents using AI. Built with Python and Streamlit, leveraging HuggingFace models for intelligent question-answering.

## ✨ Features

### 🎯 Core Features
- **AI-Powered Q&A**: Ask questions in natural language and get accurate answers from your documents
- **Multi-Format Support**: Upload PDF and TXT files
- **Persistent Library**: Documents are saved locally and tracked via SQLite
- **Smart Conversation**: Maintains context across multiple questions

### 📊 Document Management
- **Upload Multiple Files**: Drag and drop PDFs and text files
- **Document Library**: View all uploaded documents in one place
- **Search Documents**: Quickly find specific files by name
- **Document Preview**: Preview file contents before processing
- **Delete Individual Files**: Remove specific documents
- **Clear Library**: Delete all documents at once
- **Export Document List**: Download a list of all your documents

### 💬 Chat Features
- **Recent History Display**: Shows last 5 question-answer pairs
- **Quick Suggestions**: Pre-built question templates for common queries
- **Copy Answers**: Copy AI responses with one click
- **Export Chat History**: Download entire conversation as TXT file
- **Persistent History**: Chat history saved automatically

### 📈 Analytics & Stats
- **Document Count**: See total number of uploaded documents
- **Storage Size**: Track total storage used
- **Upload Timestamps**: Know when each document was added

### 🎨 User Experience
- **Clean Interface**: Intuitive sidebar navigation
- **Progress Indicators**: Visual feedback during processing
- **Responsive Design**: Works on desktop and mobile
- **Emoji Icons**: Clear visual indicators for all actions
- **Help Tooltips**: Contextual help throughout the app

## 🛠️ Tech Stack

- **Frontend**: Streamlit
- **Backend**: Python
- **AI/ML**: HuggingFace Inference API
  - Embeddings: `sentence-transformers/all-MiniLM-L6-v2`
  - LLM: `google/flan-t5-xxl`
- **Database**: SQLite
- **Vector Search**: Custom cosine similarity implementation

## 🚀 Setup

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd AskMyNotes
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Get HuggingFace API Token**
   - Go to [HuggingFace Tokens](https://huggingface.co/settings/tokens)
   - Create a new token (Read access is sufficient)
   - Copy the token

4. **Run the application**
   ```bash
   streamlit run app.py
   ```

5. **Access the app**
   - Open your browser to `http://localhost:8501`
   - Enter your HuggingFace API token in the sidebar
   - Upload documents and start asking questions!

## 📖 How to Use

### Step 1: Upload Documents
1. Click "Browse files" in the sidebar
2. Select one or more PDF or TXT files
3. Files are automatically saved to your library

### Step 2: Process Library
1. Click the "⚡ Process Library" button
2. Wait for processing to complete
3. You'll see a success message when ready

### Step 3: Ask Questions
1. Type your question in the input box
2. Or click a quick suggestion button
3. View the AI-generated answer
4. Continue asking follow-up questions

### Step 4: Manage & Export
- **Search**: Use the search box to find specific documents
- **Preview**: Click the 👁️ icon to preview file contents
- **Export Chat**: Download your conversation history
- **Clear Library**: Remove all documents when done

## 🎯 Use Cases

- **Students**: Study notes, research papers, textbooks
- **Professionals**: Business documents, reports, manuals
- **Researchers**: Academic papers, literature reviews
- **Writers**: Reference materials, drafts, research
- **Anyone**: Personal notes, articles, documentation

## 🔒 Privacy & Security

- All processing happens locally or via HuggingFace API
- No data is stored on external servers
- Documents are saved only on your machine
- API token is stored in session (not persisted)

## 🌟 Advanced Features

### Quick Question Suggestions
Pre-built questions to get started quickly:
- "Summarize the main points"
- "What are the key takeaways?"
- "Explain this in simple terms"
- "What are the important dates mentioned?"

### Document Statistics
Real-time metrics displayed in the header:
- Total number of documents
- Total storage size in MB

### Smart Search
- Search documents by filename
- Case-insensitive matching
- Instant filtering

### Chat History Management
- Automatically saves conversations
- Displays last 5 Q&A pairs
- Export full history as TXT
- Copy individual answers

## 🤝 Contributing

Contributions are welcome! Feel free to:
- Report bugs
- Suggest new features
- Submit pull requests

## 📝 License

This project is open source and available under the MIT License.

## 🙏 Acknowledgments

- Built with [Streamlit](https://streamlit.io/)
- Powered by [HuggingFace](https://huggingface.co/)
- PDF processing via [PyPDF2](https://pypdf2.readthedocs.io/)

---

**Made with ❤️ for better document understanding**
